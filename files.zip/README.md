# DeathClient v1.0.1 — Patch Notes & File Guide

## File Placement
All files go into their respective packages in your Eaglercraft source tree:

| File | Package path |
|---|---|
| Mod.java | net/minecraft/deathclient/mods/ |
| ModManager.java | net/minecraft/deathclient/mods/ |
| HudMod.java | (unchanged) net/minecraft/deathclient/mods/ |
| DeathClient.java | net/minecraft/deathclient/ |
| EventKey.java | net/minecraft/deathclient/events/ |
| EventKeyRelease.java | net/minecraft/deathclient/events/ (NEW) |
| GuiModMenu.java | net/minecraft/deathclient/ui/ |
| GuiModSettings.java | net/minecraft/deathclient/ui/ |
| All impl/*.java | net/minecraft/deathclient/mods/impl/ |

---

## 🐛 Bugs Fixed

### 1. GuiModSettings — ModeSetting cycling every frame
**File:** `GuiModSettings.java`
The `ModeSetting.cycle()` call was inside `drawScreen()`, which runs every frame.
This caused the mode to flicker rapidly whenever you hovered over it.
**Fix:** Moved the `cycle()` call exclusively into `mouseClicked()`.

### 2. HUD — Watermark drawn twice
**File:** `HUD.java`
The watermark `drawStringWithShadow("DeathClient", ...)` was called once at the
top and again inside a second `if (showWatermark)` block. FPS was also only shown
in the second block, meaning it only appeared alongside the second (duplicate) watermark.
**Fix:** Single unified render pass, with FPS/Ping as separate toggle settings.

### 3. KillAura — NullPointerException crash
**File:** `KillAura.java`
`mc.theWorld` was never null-checked before iterating `loadedEntityList`.
**Fix:** Guard at top of `onUpdate()`.

### 4. Mod.toggle() — Legit mode never actually disabled running mods
**File:** `Mod.java` + `DeathClient.java`
Calling `setLegitMode(true)` blocked new enables but never turned off already-running
cheat mods. **Fix:** `DeathClient.setLegitMode(true)` now iterates all mods and
calls `setToggled(false)` on any cheat mod that is currently active.

### 5. Mod — Missing `getCategory()`, `getDescription()`, `setToggled()` methods
**File:** `Mod.java`
`GuiModMenu` needed `getCategory()` for the new category sidebar.
`GuiModSettings` needed `getDescription()` for the sub-header.
`setToggled()` was needed for forced state changes (hold-to-activate, legit mode).

---

## ✅ New Features

### New Mods (impl/)
| Mod | Category | Notes |
|---|---|---|
| ToggleSneak | PLAYER | Holds sneak key automatically. Omni-sneak toggle. |
| XRay | RENDER | Ore ESP — renders coloured wireframe boxes around ores. Per-ore toggles + scan radius. |
| NoDynamicFOV | RENDER | Locks base FOV. See hook note below for full sprint FOV suppression. |
| FPSBoost | RENDER | Disables particles, clouds, fancy graphics to gain frames. |
| ArmorHUD | HUD | Renders your 4 armor slots + main hand with durability colour coding. |
| ScoreboardToggle | RENDER | Tracks toggle state. See hook note below for the 1-line GuiIngame patch. |
| TNTTimer | RENDER | 2D list of TNT fuse countdowns + 3D billboard tags above each TNT. |
| ReachDisplay | HUD | Live readout of your current Combat Reach and Block Reach values. |
| Compass | HUD | Cardinal direction (8-point), yaw degrees, XYZ coordinates. |
| PlayerESP | COMBAT | Per-player boxes with Static/Health/Rainbow colour, name tags, HP display, 2D tracers. |
| BlockESP | RENDER | Whitelist/Blacklist mode, per-block toggles, RGB colour, configurable radius. |
| Trajectories | RENDER | Yellow arc line for bow (charge-aware), snowball, egg, ender pearl. Stops at blocks. |
| WAILA | RENDER | Block name + coords / Entity name + HP tooltip above the hotbar. |

### New Events
| File | Purpose |
|---|---|
| EventKeyRelease.java | Fired on key-up; disables hold-to-activate mods. Wire it in Minecraft.java alongside EventKey. |

### Per-mod Keybinds (hold-to-activate)
`Mod` now has `setHoldToActivate(boolean)`. When true, pressing the key enables the
mod and releasing it (via `EventKeyRelease`) disables it. `EventKey.call()` handles
the enable side automatically.

### Improved Mod Menu
`GuiModMenu` now has:
- Category sidebar (click to filter)
- Red/green color-coded ON/OFF indicators with accent strips
- Keybind display next to each mod
- Mod count badges on each category
- Footer with control hints

### Improved Settings Screen
`GuiModSettings` now has:
- Taller, readable slider with a draggable knob
- BooleanSetting shows ON/OFF text aligned right with a colour strip
- ModeSetting shows `< Mode >` arrows aligned right
- Header shows mod description

---

## 🔧 Required MCP Hook Notes

### ScoreboardToggle (full suppression)
In `GuiIngame.renderScoreboard()`, add at the very top:
```java
Mod scoreToggle = net.minecraft.deathclient.DeathClient.getInstance()
        .getModManager().getModByName("Scoreboard Toggle");
if (scoreToggle != null && scoreToggle.isToggled()) return;
```

### NoDynamicFOV (full sprint FOV suppression)
In `EntityRenderer.getFOVModifier()`, add before the return:
```java
Mod noDynFOV = net.minecraft.deathclient.DeathClient.getInstance()
        .getModManager().getModByName("No Dynamic FOV");
if (noDynFOV != null && noDynFOV.isToggled()) return 1.0F;
```

### EventKeyRelease (hold-to-activate)
In `Minecraft.java`, wherever key release events are handled (usually the same place
`EventKey` is fired), add:
```java
new net.minecraft.deathclient.events.EventKeyRelease(keyCode).call();
```

### CombatReach / BlockReach (reach extension)
In `PlayerControllerMP`, patch the reach distance checks to read from these mods:
```java
Mod combatReach = DeathClient.getInstance().getModManager().getModByName("Combat Reach");
if (combatReach != null && combatReach.isToggled()) {
    return ((NumberSetting) combatReach.getSettingByName("Distance")).getValue();
}
```
